export default function Center({ children }) {
  return <div className="container max-w-2xl px-8 mx-auto">{children}</div>;
}
