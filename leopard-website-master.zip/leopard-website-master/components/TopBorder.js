export default function TopBorder() {
  return <div className="border-t-8 border-indigo-600" />;
}
